library('devtools')

document(".")
#test(".")
#build(".")
#install("ProjectTemplate")

#check(".")
#run_examples()
#release()
