save.project <- function(cache_dir="cache"){
  # saves all the variables in the workplace with a .out postfix
  vars = ls()
  indices = grep("\\.out$", vars) 
  for (index in indices){
    save(
      list=c(vars[index]), 
      file=paste(cache_dir, vars[index], sep="/")
    )  
  }    
}
