#' Read an Excel 2004 file with a .xls file extension.
#'
#' This function will load the specified Excel file into memory using the
#' gdata package. Each sheet of the Excel workbook will be read into a
#' separate variable in the global environment.
#'
#' @return No value is returned; this function is called for its side effects.
#'
#' @examples
#' xls.reader('example.xls', 'data/example.xls', 'example')
xls.reader <- function(data.file, filename, workbook.name)
{
  library('gdata')
  sheets <- sheetNames(filename)
  
  for (sheet.name in sheets)
  {
    variable.name <- paste(workbook.name, ProjectTemplate:::clean.variable.name(sheet.name), sep = ".")
    tryCatch(assign(variable.name,
                    read.xls(filename,
                             sheet = sheet.name),
                    envir = .GlobalEnv),
             error = function(e)
             {
               warning(paste("The worksheet", sheet.name, "didn't load correctly."))
             })
  }
}
