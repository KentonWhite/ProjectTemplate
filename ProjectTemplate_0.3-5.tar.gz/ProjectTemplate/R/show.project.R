show.project <- function()
{
  print(project.info)
}
