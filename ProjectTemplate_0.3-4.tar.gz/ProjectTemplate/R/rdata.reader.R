rdata.reader <- function(data.file, filename, variable.name)
{
  load(filename, envir = .GlobalEnv)
}
