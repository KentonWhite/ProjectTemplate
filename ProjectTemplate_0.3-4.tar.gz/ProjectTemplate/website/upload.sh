cp ../README.markdown .
cp ../TODO.markdown .

ruby generate_website.rb

scp *.html johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
scp *.css johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
scp letters.csv.bz2 johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
scp *.jpg johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
scp *.png johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
