r.reader <- function(data.file, filename, variable.name)
{
  source(filename)
}
