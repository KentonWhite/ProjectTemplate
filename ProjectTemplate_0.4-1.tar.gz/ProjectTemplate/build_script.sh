#!/bin/bash

rm ProjectTemplate_*.tar.gz
rm -rf ProjectTemplate.Rcheck
R CMD BUILD .
R CMD CHECK ProjectTemplate_*.tar.gz
rm -rf ProjectTemplate.Rcheck
R CMD INSTALL ProjectTemplate_*.tar.gz
