CREATE TABLE example_28 (N INTEGER PRIMARY KEY, Prime INTEGER);
INSERT INTO example_28 (N, Prime) VALUES (1, 2);
INSERT INTO example_28 (N, Prime) VALUES (2, 3);
INSERT INTO example_28 (N, Prime) VALUES (3, 5);
INSERT INTO example_28 (N, Prime) VALUES (4, 7);
INSERT INTO example_28 (N, Prime) VALUES (5, 11);

CREATE TABLE example_29 (N INTEGER PRIMARY KEY, Prime INTEGER);
INSERT INTO example_29 (N, Prime) VALUES (1, 2);
INSERT INTO example_29 (N, Prime) VALUES (2, 3);
INSERT INTO example_29 (N, Prime) VALUES (3, 5);
INSERT INTO example_29 (N, Prime) VALUES (4, 7);
INSERT INTO example_29 (N, Prime) VALUES (5, 11);

CREATE TABLE example_30a (N INTEGER PRIMARY KEY, Prime INTEGER);
INSERT INTO example_30a (N, Prime) VALUES (1, 2);
INSERT INTO example_30a (N, Prime) VALUES (2, 3);
INSERT INTO example_30a (N, Prime) VALUES (3, 5);
INSERT INTO example_30a (N, Prime) VALUES (4, 7);
INSERT INTO example_30a (N, Prime) VALUES (5, 11);

CREATE TABLE example_30b (N INTEGER PRIMARY KEY, Prime INTEGER);
INSERT INTO example_30b (N, Prime) VALUES (1, 2);
INSERT INTO example_30b (N, Prime) VALUES (2, 3);
INSERT INTO example_30b (N, Prime) VALUES (3, 5);
INSERT INTO example_30b (N, Prime) VALUES (4, 7);
INSERT INTO example_30b (N, Prime) VALUES (5, 11);

CREATE TABLE example_31a (N INTEGER PRIMARY KEY, Prime INTEGER);
INSERT INTO example_31a (N, Prime) VALUES (1, 2);
INSERT INTO example_31a (N, Prime) VALUES (2, 3);
INSERT INTO example_31a (N, Prime) VALUES (3, 5);
INSERT INTO example_31a (N, Prime) VALUES (4, 7);
INSERT INTO example_31a (N, Prime) VALUES (5, 11);

CREATE TABLE example_31b (N INTEGER PRIMARY KEY, Prime INTEGER);
INSERT INTO example_31b (N, Prime) VALUES (1, 2);
INSERT INTO example_31b (N, Prime) VALUES (2, 3);
INSERT INTO example_31b (N, Prime) VALUES (3, 5);
INSERT INTO example_31b (N, Prime) VALUES (4, 7);
INSERT INTO example_31b (N, Prime) VALUES (5, 11);
