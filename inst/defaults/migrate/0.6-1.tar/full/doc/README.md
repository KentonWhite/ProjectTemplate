Here you can store any documentation that you've written about your analysis.
