library('staticdocs')

build_package('ProjectTemplate', 'html')
