library('RPostgreSQL')

drv <- dbDriver("PostgreSQL")

connection <- dbConnect(drv,
                        user = 'postgres',
                        password = 'eishudor',
                        host = 'localhost',
                        dbname = 'test')

dbGetQuery(connection, 'SELECT * FROM example_29')

dbDisconnect(connection)
