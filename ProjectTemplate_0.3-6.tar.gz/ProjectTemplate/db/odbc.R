library('RODBC')

connection <- odbcConnect('test')

sqlQuery(connection, 'SELECT * FROM example_29')
results <- sqlGetResults(connection, as.is = TRUE)

odbcClose(connection)
