scp *.html johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
scp *.css johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
