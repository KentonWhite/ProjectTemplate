#!/usr/local/bin/ruby

files = Dir.new('.').entries

files.each do |file|
  if file.match(/\.markdown$/)
    html_file = file.sub(/\.markdown/, '.html')
    `Markdown.pl #{file} > #{html_file}`
  end
end
