run.tests <- function()
{
  source('lib/run_tests.R')
}

test.project <- run.tests
