library('ProjectTemplate')

load.project()

test_dir('tests', reporter = 'summary')
