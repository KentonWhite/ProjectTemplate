cp ../README.markdown .
cp ../TODO.markdown .

ruby generate_website.rb

scp *.html johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
scp *.css johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
scp letters.csv.bz2 johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
scp *.jpg johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
scp *.png johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate
scp philapd.db.zip johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate

scp -r images johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate/images
scp -r javascripts johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate/javascripts
scp -r stylesheets johnmyle@johnmyleswhite.com:/home2/johnmyle/public_html/projecttemplate/stylesheets
