Directories
SQLite version control, seemless data storage
Watchers / automatic updating of contents
