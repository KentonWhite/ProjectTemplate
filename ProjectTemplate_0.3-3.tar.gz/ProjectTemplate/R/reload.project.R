reload.project <- function()
{
  rm(list = ls())
  load.project()
}
