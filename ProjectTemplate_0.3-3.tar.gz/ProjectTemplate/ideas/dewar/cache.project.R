cache.project <- function()
{
  for (to.be.cached.variable in ls(globalenv()))
  {
    if (class(get(to.be.cached.variable, envir = globalenv())) != 'function')
    {
      save(get(to.be.cached.variable,
               envir = globalenv()),
           file = file.path('cache',
                            paste(to.be.cached.variable,
                                  '.RData',
                                  sep = '')))
    }
  }
}
